import { MapPin, Maximize, Home, TreePine, Droplets, Sun } from "lucide-react";

export interface Property {
  id: string;
  title: string;
  price: number;
  size: number; // in acres
  location: string;
  image: string;
  type: "Raw Land" | "Farm" | "Ranch" | "Waterfront" | "Recreational";
  description: string;
  features: string[];
  isFeatured?: boolean;
}

export const properties: Property[] = [
  {
    id: "1",
    title: "5 Acre Wooded Retreat",
    price: 45000,
    size: 5.2,
    location: "Asheville, NC",
    image: "https://images.unsplash.com/photo-1500382017468-9049fed747ef?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80",
    type: "Recreational",
    description: "Beautiful wooded lot perfect for a cabin or weekend getaway. Rolling hills and mature hardwoods.",
    features: ["Wooded", "Road Access", "Electric Nearby"],
    isFeatured: true
  },
  {
    id: "2",
    title: "Sunny Meadow Farm",
    price: 125000,
    size: 15.5,
    location: "Lexington, KY",
    image: "https://images.unsplash.com/photo-1500076656116-558758c991c1?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80",
    type: "Farm",
    description: "Flat, open pasture ready for farming or livestock. Fenced perimeter with small pond.",
    features: ["Pasture", "Fenced", "Pond", "Barn"],
    isFeatured: true
  },
  {
    id: "3",
    title: "Mountain View Building Site",
    price: 89000,
    size: 2.1,
    location: "Boulder, CO",
    image: "https://images.unsplash.com/photo-1513836279014-a89f7a76ae86?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80",
    type: "Raw Land",
    description: "Stunning views of the flatirons. Ready to build with septic approval and well permit.",
    features: ["Mountain View", "Buildable", "Utilities Available"],
    isFeatured: true
  },
  {
    id: "4",
    title: "Lakeside Parcel",
    price: 210000,
    size: 3.5,
    location: "Traverse City, MI",
    image: "https://images.unsplash.com/photo-1472214103451-9374bd1c798e?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80",
    type: "Waterfront",
    description: "Premium lakefront property with sandy beach access. Perfect for a vacation home.",
    features: ["Waterfront", "Beach Access", "Dock Permitted"],
    isFeatured: false
  },
  {
    id: "5",
    title: "High Desert Ranch",
    price: 65000,
    size: 40,
    location: "Taos, NM",
    image: "https://images.unsplash.com/photo-1444858291040-58f756a3bdd6?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80",
    type: "Ranch",
    description: "Expansive acreage with sagebrush and stunning sunsets. Off-grid potential.",
    features: ["Off-grid", "Secluded", "Hunting"],
    isFeatured: false
  },
  {
    id: "6",
    title: "River Valley Homestead",
    price: 155000,
    size: 10,
    location: "Eugene, OR",
    image: "https://images.unsplash.com/photo-1464226184884-fa280b87c399?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80",
    type: "Farm",
    description: "Fertile soil near the river. Great for organic farming or a sustainable homestead.",
    features: ["River Frontage", "Fertile Soil", "Water Rights"],
    isFeatured: true
  }
];
