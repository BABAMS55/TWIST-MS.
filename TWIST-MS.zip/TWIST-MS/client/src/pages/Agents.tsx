import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Mail, Phone, MapPin, Star, CreditCard, Check } from "lucide-react";
import { useState } from "react";
import { useLocation } from "wouter";

export default function Agents() {
  const [, setLocation] = useLocation();
  const [step, setStep] = useState("details");

  const agents = [
    {
      id: 1,
      name: "John Doe",
      email: "john@twistms.com",
      phone: "+1 (555) 123-4567",
      specialization: "Residential Land",
      location: "Austin, TX",
      listings: 24,
      rating: 4.9
    },
    {
      id: 2,
      name: "Sarah Johnson",
      email: "sarah@twistms.com",
      phone: "+1 (555) 234-5678",
      specialization: "Agricultural & Farm Land",
      location: "Dallas, TX",
      listings: 18,
      rating: 4.8
    },
    {
      id: 3,
      name: "Michael Chen",
      email: "michael@twistms.com",
      phone: "+1 (555) 345-6789",
      specialization: "Commercial & Investment Land",
      location: "Houston, TX",
      listings: 31,
      rating: 5.0
    },
  ];

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Navbar />
      
      <main className="flex-1">
        <div className="bg-gradient-to-r from-primary/20 to-accent/20 py-12 border-b">
          <div className="container mx-auto px-4 text-center">
            <h1 className="font-heading text-3xl md:text-4xl font-bold mb-2">Our Agents</h1>
            <p className="text-muted-foreground text-lg">Expert professionals ready to help you buy, sell, or invest</p>
          </div>
        </div>

        <div className="container mx-auto px-4 py-16">
          <Tabs defaultValue="browse" className="w-full">
            <TabsList className="grid w-full grid-cols-2 mb-12">
              <TabsTrigger value="browse">Browse Agents</TabsTrigger>
              <TabsTrigger value="become">Become an Agent</TabsTrigger>
            </TabsList>

            <TabsContent value="browse">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {agents.map(agent => (
                  <Card key={agent.id} className="flex flex-col hover:shadow-lg transition-shadow">
                    <div className="h-32 bg-gradient-to-r from-primary/20 to-accent/20" />
                    <CardContent className="p-6 flex-1 flex flex-col">
                      <div className="mb-4 -mt-20 relative z-10">
                        <div className="w-16 h-16 rounded-full bg-gradient-to-br from-primary to-blue-600 flex items-center justify-center text-white font-bold text-2xl border-4 border-background mx-auto">
                          {agent.name.split(' ').map(n => n[0]).join('')}
                        </div>
                      </div>
                      
                      <h3 className="font-heading font-bold text-lg text-center mb-1">{agent.name}</h3>
                      <p className="text-primary text-sm text-center font-medium mb-4">{agent.specialization}</p>
                      
                      <div className="flex items-center justify-center gap-1 mb-4">
                        {[...Array(5)].map((_, i) => (
                          <Star key={i} className={`w-4 h-4 ${i < Math.floor(agent.rating) ? 'fill-accent text-accent' : 'text-muted-foreground'}`} />
                        ))}
                        <span className="text-sm text-muted-foreground ml-2">{agent.rating}</span>
                      </div>

                      <div className="space-y-3 flex-1 text-sm">
                        <div className="flex items-center gap-2 text-muted-foreground">
                          <MapPin className="w-4 h-4 text-primary shrink-0" />
                          {agent.location}
                        </div>
                        <div className="flex items-center gap-2 text-muted-foreground">
                          <Mail className="w-4 h-4 text-primary shrink-0" />
                          <a href={`mailto:${agent.email}`} className="hover:text-primary transition-colors">{agent.email}</a>
                        </div>
                        <div className="flex items-center gap-2 text-muted-foreground">
                          <Phone className="w-4 h-4 text-primary shrink-0" />
                          {agent.phone}
                        </div>
                        <p className="text-sm pt-2"><span className="font-semibold">{agent.listings}</span> active listings</p>
                      </div>

                      <Button className="w-full mt-4" variant="outline">Contact Agent</Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="become">
              <Card className="max-w-2xl mx-auto">
                <CardHeader>
                  <CardTitle>Become a TWIST MS Agent</CardTitle>
                  <CardDescription>Join our network of professional real estate agents</CardDescription>
                </CardHeader>
                <CardContent>
                  <Tabs value={step} onValueChange={setStep}>
                    <TabsList className="grid w-full grid-cols-2 mb-8">
                      <TabsTrigger value="details">Your Details</TabsTrigger>
                      <TabsTrigger value="payment">Payment</TabsTrigger>
                    </TabsList>

                    <TabsContent value="details" className="space-y-6">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="space-y-2">
                          <Label htmlFor="fname">First Name</Label>
                          <Input id="fname" placeholder="John" />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="lname">Last Name</Label>
                          <Input id="lname" placeholder="Doe" />
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="aemail">Email</Label>
                        <Input id="aemail" type="email" placeholder="john@example.com" />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="aphone">Phone</Label>
                        <Input id="aphone" placeholder="+1 (555) 123-4567" />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="location">Service Area</Label>
                        <Input id="location" placeholder="City, State" />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="specialization">Specialization</Label>
                        <select className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50">
                          <option>Residential Land</option>
                          <option>Agricultural & Farm Land</option>
                          <option>Commercial & Investment Land</option>
                          <option>Waterfront Properties</option>
                          <option>Multiple Specialties</option>
                        </select>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="bio">Professional Bio</Label>
                        <textarea 
                          id="bio"
                          className="flex min-h-[100px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm shadow-sm placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50"
                          placeholder="Tell us about your real estate experience..."
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="license">Real Estate License #</Label>
                        <Input id="license" placeholder="Your license number" />
                      </div>

                      <Button onClick={() => setStep("payment")} className="w-full">Next: Payment</Button>
                    </TabsContent>

                    <TabsContent value="payment" className="space-y-6">
                      <div className="bg-secondary/30 p-6 rounded-lg space-y-3">
                        <h3 className="font-heading font-bold">Agent Registration Fee</h3>
                        <div className="flex justify-between items-center text-lg">
                          <span>Flat one-time listing commission</span>
                          <span className="font-bold text-primary text-2xl">$50</span>
                        </div>
                        <p className="text-sm text-muted-foreground mt-4">
                          This covers your agent profile setup, 180 days of feature listings, and access to the agent dashboard.
                        </p>
                      </div>

                      <div className="space-y-4">
                        <h3 className="font-heading font-bold flex items-center gap-2">
                          <CreditCard className="w-5 h-5 text-primary" />
                          Credit Card Details
                        </h3>

                        <div className="space-y-2">
                          <Label htmlFor="agcardholder">Cardholder Name</Label>
                          <Input id="agcardholder" placeholder="John Doe" />
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="agcard">Card Number</Label>
                          <Input id="agcard" placeholder="4532 1234 5678 9010" />
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label htmlFor="agexpiry">Expiry Date</Label>
                            <Input id="agexpiry" placeholder="MM/YY" />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="agcvv">CVV</Label>
                            <Input id="agcvv" placeholder="123" />
                          </div>
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="agemail">Billing Email</Label>
                          <Input id="agemail" type="email" placeholder="billing@example.com" />
                        </div>
                      </div>

                      <div className="bg-primary/10 border border-primary/20 rounded-lg p-4 space-y-2">
                        <div className="flex gap-2">
                          <Check className="w-5 h-5 text-primary shrink-0" />
                          <span className="text-sm font-medium">Professional agent profile with photo</span>
                        </div>
                        <div className="flex gap-2">
                          <Check className="w-5 h-5 text-primary shrink-0" />
                          <span className="text-sm font-medium">Direct contact information displayed to buyers</span>
                        </div>
                        <div className="flex gap-2">
                          <Check className="w-5 h-5 text-primary shrink-0" />
                          <span className="text-sm font-medium">Access to leads and buyer inquiries</span>
                        </div>
                        <div className="flex gap-2">
                          <Check className="w-5 h-5 text-primary shrink-0" />
                          <span className="text-sm font-medium">Agent dashboard and analytics</span>
                        </div>
                      </div>

                      <div className="flex gap-4">
                        <Button variant="outline" onClick={() => setStep("details")} className="flex-1">Back</Button>
                        <Button 
                          onClick={() => setLocation("/dashboard")}
                          className="flex-1 bg-gradient-to-r from-primary to-blue-600"
                        >
                          Pay $50 & Register
                        </Button>
                      </div>
                    </TabsContent>
                  </Tabs>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>

      <Footer />
    </div>
  );
}
