import Navbar from "@/components/layout/Navbar";
import Hero from "@/components/home/Hero";
import PropertyCard from "@/components/property/PropertyCard";
import Footer from "@/components/layout/Footer";
import { properties } from "@/lib/mockData";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { Shield, Users, CheckCircle, TrendingUp } from "lucide-react";

export default function Home() {
  const featuredProperties = properties.filter(p => p.isFeatured).slice(0, 3);

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Navbar />
      
      <main className="flex-1">
        <Hero />

        {/* Featured Listings Section */}
        <section className="py-20 container mx-auto px-4">
          <div className="flex items-end justify-between mb-10">
            <div>
              <span className="text-primary font-semibold text-sm tracking-wider uppercase mb-2 block">Featured Opportunities</span>
              <h2 className="font-heading text-3xl md:text-4xl font-bold text-foreground">
                Premium Land for Sale
              </h2>
            </div>
            <Link href="/listings">
              <Button variant="ghost" className="hidden md:flex">
                View All Listings
              </Button>
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {featuredProperties.map((property) => (
              <PropertyCard key={property.id} property={property} />
            ))}
          </div>
          
          <div className="mt-8 text-center md:hidden">
            <Link href="/listings">
              <Button variant="outline" size="lg">View All Listings</Button>
            </Link>
          </div>
        </section>

        {/* Why Choose Us Section */}
        <section className="py-20 bg-secondary/30">
          <div className="container mx-auto px-4">
            <div className="text-center max-w-2xl mx-auto mb-16">
              <h2 className="font-heading text-3xl md:text-4xl font-bold mb-4">Why Trust TWIST MS?</h2>
              <p className="text-muted-foreground text-lg">
                We're revolutionizing how land is bought and sold by removing the middlemen
                and providing transparent, direct access to property owners.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
              <Feature 
                icon={Shield} 
                title="Verified Listings" 
                description="Every listing is vetted to ensure ownership verification and clean titles, giving you peace of mind."
              />
              <Feature 
                icon={Users} 
                title="Direct Owner Access" 
                description="Connect directly with sellers. No hidden agent fees or commissions added to the price."
              />
              <Feature 
                icon={TrendingUp} 
                title="Investment Growth" 
                description="Land is a tangible asset that historically appreciates in value. Secure your future wealth today."
              />
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 container mx-auto px-4">
          <div className="bg-primary rounded-3xl p-10 md:p-16 text-center text-primary-foreground relative overflow-hidden">
            <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-10"></div>
            <div className="relative z-10 max-w-3xl mx-auto">
              <h2 className="font-heading text-3xl md:text-5xl font-bold mb-6">
                Ready to Find Your Dream Property?
              </h2>
              <p className="text-primary-foreground/90 text-lg mb-8 leading-relaxed">
                Whether you're looking for a weekend getaway, a farm for your family, 
                or a solid investment, we have thousands of verified listings waiting for you.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Link href="/listings">
                  <Button size="lg" variant="secondary" className="h-14 px-8 text-lg font-semibold w-full sm:w-auto">
                    Browse Listings
                  </Button>
                </Link>
                <Link href="/auth?tab=register">
                  <Button size="lg" variant="outline" className="h-14 px-8 text-lg font-semibold bg-transparent border-primary-foreground text-primary-foreground hover:bg-primary-foreground hover:text-primary w-full sm:w-auto">
                    Sell Your Land
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}

function Feature({ icon: Icon, title, description }: { icon: any, title: string, description: string }) {
  return (
    <div className="bg-background p-8 rounded-xl shadow-sm border hover:shadow-md transition-shadow">
      <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center text-primary mb-6">
        <Icon className="w-6 h-6" />
      </div>
      <h3 className="font-heading font-bold text-xl mb-3">{title}</h3>
      <p className="text-muted-foreground leading-relaxed">
        {description}
      </p>
    </div>
  );
}
