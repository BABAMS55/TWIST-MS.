import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { TrendingUp, PieChart, Target, DollarSign, ArrowUpRight, CheckCircle } from "lucide-react";
import { Link } from "wouter";

export default function Invest() {
  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Navbar />
      
      <main className="flex-1">
        <div className="bg-gradient-to-r from-primary/20 to-accent/20 py-12 border-b">
          <div className="container mx-auto px-4 text-center">
            <h1 className="font-heading text-3xl md:text-4xl font-bold mb-2">Land Investment Guide</h1>
            <p className="text-muted-foreground text-lg">Build wealth through real property ownership</p>
          </div>
        </div>

        <div className="container mx-auto px-4 py-16">
          {/* Why Invest in Land */}
          <section className="mb-16">
            <h2 className="font-heading text-2xl font-bold mb-8">Why Invest in Land?</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <InvestCard 
                icon={TrendingUp}
                title="Long-Term Appreciation"
                description="Land values historically appreciate 3-5% annually, providing steady wealth growth."
              />
              <InvestCard 
                icon={PieChart}
                title="Portfolio Diversification"
                description="Real estate adds tangible assets to your investment portfolio, reducing risk."
              />
              <InvestCard 
                icon={Target}
                title="Low Maintenance"
                description="Raw land requires minimal upkeep compared to rental properties or commercial real estate."
              />
            </div>
          </section>

          {/* Investment Types */}
          <section className="mb-16">
            <h2 className="font-heading text-2xl font-bold mb-8">Types of Land Investments</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <DollarSign className="w-5 h-5 text-primary" />
                    Residential Development
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <p className="text-muted-foreground">Purchase land in growing neighborhoods to sell for residential development.</p>
                  <ul className="space-y-2 text-sm">
                    <li className="flex gap-2"><CheckCircle className="w-4 h-4 text-primary shrink-0" /> High appreciation potential</li>
                    <li className="flex gap-2"><CheckCircle className="w-4 h-4 text-primary shrink-0" /> Near city centers</li>
                    <li className="flex gap-2"><CheckCircle className="w-4 h-4 text-primary shrink-0" /> 5-10 year holding period</li>
                  </ul>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <DollarSign className="w-5 h-5 text-accent" />
                    Agricultural Investment
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <p className="text-muted-foreground">Farm or ranch land for agricultural use with potential lease income.</p>
                  <ul className="space-y-2 text-sm">
                    <li className="flex gap-2"><CheckCircle className="w-4 h-4 text-accent shrink-0" /> Consistent lease income</li>
                    <li className="flex gap-2"><CheckCircle className="w-4 h-4 text-accent shrink-0" /> Lower entry prices</li>
                    <li className="flex gap-2"><CheckCircle className="w-4 h-4 text-accent shrink-0" /> Long-term hold strategy</li>
                  </ul>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <DollarSign className="w-5 h-5 text-primary" />
                    Commercial Land
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <p className="text-muted-foreground">Highway and commercial zoned land for retail and business development.</p>
                  <ul className="space-y-2 text-sm">
                    <li className="flex gap-2"><CheckCircle className="w-4 h-4 text-primary shrink-0" /> High profit potential</li>
                    <li className="flex gap-2"><CheckCircle className="w-4 h-4 text-primary shrink-0" /> Leasing opportunities</li>
                    <li className="flex gap-2"><CheckCircle className="w-4 h-4 text-primary shrink-0" /> Strategic locations</li>
                  </ul>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <DollarSign className="w-5 h-5 text-accent" />
                    Recreational Land
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <p className="text-muted-foreground">Vacation and hobby land near lakes, mountains, and outdoor destinations.</p>
                  <ul className="space-y-2 text-sm">
                    <li className="flex gap-2"><CheckCircle className="w-4 h-4 text-accent shrink-0" /> High demand markets</li>
                    <li className="flex gap-2"><CheckCircle className="w-4 h-4 text-accent shrink-0" /> Resale flexibility</li>
                    <li className="flex gap-2"><CheckCircle className="w-4 h-4 text-accent shrink-0" /> Personal use option</li>
                  </ul>
                </CardContent>
              </Card>
            </div>
          </section>

          {/* Investment Strategy */}
          <section className="mb-16">
            <h2 className="font-heading text-2xl font-bold mb-8">Investment Strategy Tips</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="space-y-6">
                <div className="flex gap-4">
                  <div className="w-8 h-8 rounded-full bg-primary/20 text-primary flex items-center justify-center font-bold shrink-0">1</div>
                  <div>
                    <h3 className="font-bold mb-2">Research Markets Thoroughly</h3>
                    <p className="text-muted-foreground text-sm">Analyze growth trends, population migration, and development plans in your target areas.</p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <div className="w-8 h-8 rounded-full bg-primary/20 text-primary flex items-center justify-center font-bold shrink-0">2</div>
                  <div>
                    <h3 className="font-bold mb-2">Check Zoning & Permits</h3>
                    <p className="text-muted-foreground text-sm">Verify zoning compliance and development permit requirements before purchasing.</p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <div className="w-8 h-8 rounded-full bg-primary/20 text-primary flex items-center justify-center font-bold shrink-0">3</div>
                  <div>
                    <h3 className="font-bold mb-2">Know Your Costs</h3>
                    <p className="text-muted-foreground text-sm">Factor in property taxes, insurance, maintenance, and holding costs into your analysis.</p>
                  </div>
                </div>
              </div>

              <div className="space-y-6">
                <div className="flex gap-4">
                  <div className="w-8 h-8 rounded-full bg-accent/20 text-accent flex items-center justify-center font-bold shrink-0">4</div>
                  <div>
                    <h3 className="font-bold mb-2">Diversify Geographic Locations</h3>
                    <p className="text-muted-foreground text-sm">Spread investments across multiple states and markets to reduce regional economic risks.</p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <div className="w-8 h-8 rounded-full bg-accent/20 text-accent flex items-center justify-center font-bold shrink-0">5</div>
                  <div>
                    <h3 className="font-bold mb-2">Have a Long-Term Vision</h3>
                    <p className="text-muted-foreground text-sm">Most successful land investors hold for 5-10+ years to maximize appreciation.</p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <div className="w-8 h-8 rounded-full bg-accent/20 text-accent flex items-center justify-center font-bold shrink-0">6</div>
                  <div>
                    <h3 className="font-bold mb-2">Network with Professionals</h3>
                    <p className="text-muted-foreground text-sm">Connect with agents, surveyors, and attorneys to build your investment team.</p>
                  </div>
                </div>
              </div>
            </div>
          </section>

          {/* CTA */}
          <section className="bg-gradient-to-r from-primary to-blue-600 rounded-3xl p-12 text-center text-white">
            <h2 className="font-heading text-3xl font-bold mb-4">Start Your Investment Journey</h2>
            <p className="text-white/90 mb-8 max-w-2xl mx-auto">
              Browse thousands of land investment opportunities on TWIST MS Real Estate.
            </p>
            <Link href="/listings">
              <Button size="lg" variant="secondary" className="font-bold">
                Browse Investment Properties
              </Button>
            </Link>
          </section>
        </div>
      </main>

      <Footer />
    </div>
  );
}

function InvestCard({ icon: Icon, title, description }: { icon: any, title: string, description: string }) {
  return (
    <Card>
      <CardContent className="p-6 text-center">
        <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center text-primary mx-auto mb-4">
          <Icon className="w-6 h-6" />
        </div>
        <h3 className="font-heading font-bold text-lg mb-2">{title}</h3>
        <p className="text-muted-foreground text-sm">{description}</p>
      </CardContent>
    </Card>
  );
}
