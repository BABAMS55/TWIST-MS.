import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { CreditCard, DollarSign, Upload, MapPin } from "lucide-react";
import { useState } from "react";
import { useLocation } from "wouter";

export default function Sell() {
  const [, setLocation] = useLocation();
  const [step, setStep] = useState("details");

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Navbar />
      
      <main className="flex-1">
        <div className="bg-gradient-to-r from-primary/20 to-accent/20 py-12 border-b">
          <div className="container mx-auto px-4 text-center">
            <h1 className="font-heading text-3xl md:text-4xl font-bold mb-2">List Your Land</h1>
            <p className="text-muted-foreground text-lg">Sell directly to buyers. Only $50 to list your property.</p>
          </div>
        </div>

        <div className="container mx-auto px-4 py-12">
          <div className="max-w-4xl mx-auto">
            {/* Pricing Card */}
            <Card className="mb-8 border-t-4 border-t-primary shadow-lg">
              <CardContent className="p-6">
                <div className="flex flex-col md:flex-row items-center justify-between gap-6">
                  <div>
                    <h3 className="font-heading font-bold text-xl mb-2">Listing Price</h3>
                    <p className="text-muted-foreground">Post your land and reach thousands of buyers nationwide</p>
                  </div>
                  <div className="text-right">
                    <p className="text-4xl font-bold text-primary">$50</p>
                    <p className="text-sm text-muted-foreground">One-time listing fee</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Form Tabs */}
            <Tabs value={step} onValueChange={setStep} className="w-full">
              <TabsList className="grid w-full grid-cols-3 mb-8">
                <TabsTrigger value="details">Property Details</TabsTrigger>
                <TabsTrigger value="images">Images & Documents</TabsTrigger>
                <TabsTrigger value="payment">Payment</TabsTrigger>
              </TabsList>

              <TabsContent value="details">
                <Card>
                  <CardHeader>
                    <CardTitle>Property Information</CardTitle>
                    <CardDescription>Provide details about your land</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <Label htmlFor="title">Property Title</Label>
                        <Input id="title" placeholder="e.g., Beautiful 5-Acre Wooded Lot" />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="price">Asking Price ($)</Label>
                        <Input id="price" type="number" placeholder="50000" />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <Label htmlFor="acres">Acreage</Label>
                        <Input id="acres" type="number" step="0.1" placeholder="5.2" />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="type">Property Type</Label>
                        <select className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50">
                          <option>Raw Land</option>
                          <option>Farm</option>
                          <option>Ranch</option>
                          <option>Waterfront</option>
                          <option>Recreational</option>
                        </select>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="location">Location (City, State)</Label>
                      <div className="flex gap-2">
                        <MapPin className="w-5 h-5 text-muted-foreground mt-2.5" />
                        <Input id="location" placeholder="Austin, Texas" />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="description">Description</Label>
                      <textarea 
                        id="description"
                        className="flex min-h-[120px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm shadow-sm placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50"
                        placeholder="Describe your property, features, access, utilities, etc..."
                      />
                    </div>

                    <Button onClick={() => setStep("images")} className="w-full">Next: Add Images</Button>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="images">
                <Card>
                  <CardHeader>
                    <CardTitle>Images & Documents</CardTitle>
                    <CardDescription>Upload photos and supporting documents</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="border-2 border-dashed rounded-lg p-8 text-center cursor-pointer hover:bg-secondary/20 transition-colors">
                      <Upload className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
                      <p className="font-medium mb-1">Drop images here or click to upload</p>
                      <p className="text-sm text-muted-foreground mb-4">JPG, PNG up to 10MB each</p>
                      <Button variant="outline" type="button">Select Images</Button>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="survey">Survey or Deed (Optional)</Label>
                      <Input id="survey" type="file" />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="zoning">Zoning Information (Optional)</Label>
                      <Input id="zoning" type="file" />
                    </div>

                    <div className="flex gap-4">
                      <Button variant="outline" onClick={() => setStep("details")} className="flex-1">Back</Button>
                      <Button onClick={() => setStep("payment")} className="flex-1">Next: Payment</Button>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="payment">
                <Card>
                  <CardHeader>
                    <CardTitle>Complete Your Listing</CardTitle>
                    <CardDescription>Secure payment via credit card</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    {/* Summary */}
                    <div className="bg-secondary/30 p-6 rounded-lg space-y-4 mb-6">
                      <div className="flex justify-between items-center pb-4 border-b">
                        <span className="font-medium">Listing Fee</span>
                        <span className="font-bold text-xl text-primary">$50.00</span>
                      </div>
                      <p className="text-sm text-muted-foreground">
                        Your listing will be live for 180 days with unlimited edits and full access to buyer inquiries.
                      </p>
                    </div>

                    {/* Payment Form */}
                    <div className="space-y-4">
                      <h3 className="font-heading font-bold flex items-center gap-2">
                        <CreditCard className="w-5 h-5 text-primary" />
                        Credit Card Details
                      </h3>

                      <div className="space-y-2">
                        <Label htmlFor="cardholder">Cardholder Name</Label>
                        <Input id="cardholder" placeholder="John Doe" />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="card">Card Number</Label>
                        <Input id="card" placeholder="4532 1234 5678 9010" />
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="expiry">Expiry Date</Label>
                          <Input id="expiry" placeholder="MM/YY" />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="cvv">CVV</Label>
                          <Input id="cvv" placeholder="123" />
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="email">Billing Email</Label>
                        <Input id="email" type="email" placeholder="your@email.com" />
                      </div>
                    </div>

                    <div className="flex gap-4">
                      <Button variant="outline" onClick={() => setStep("images")} className="flex-1">Back</Button>
                      <Button 
                        onClick={() => {
                          setLocation("/dashboard");
                        }}
                        className="flex-1 bg-gradient-to-r from-primary to-blue-600"
                      >
                        Pay $50 & List Property
                      </Button>
                    </div>

                    <p className="text-xs text-muted-foreground text-center">
                      Your payment information is secure and encrypted.
                    </p>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
