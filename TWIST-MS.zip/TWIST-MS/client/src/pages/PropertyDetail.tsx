import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import { properties } from "@/lib/mockData";
import { Button } from "@/components/ui/button";
import { useRoute } from "wouter";
import { MapPin, Ruler, Share2, Heart, Calendar, ArrowLeft, Mail, Phone, ShieldCheck, CheckCircle } from "lucide-react";
import { Link } from "wouter";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Input } from "@/components/ui/input";

export default function PropertyDetail() {
  const [match, params] = useRoute("/property/:id");
  const property = properties.find(p => p.id === params?.id);

  if (!property) {
    return (
      <div className="min-h-screen flex items-center justify-center flex-col gap-4">
        <h1 className="text-2xl font-bold">Property Not Found</h1>
        <Link href="/listings"><Button>Back to Listings</Button></Link>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Navbar />
      
      <main className="flex-1">
        {/* Breadcrumbs & Actions */}
        <div className="bg-secondary/30 border-b py-4">
          <div className="container mx-auto px-4 flex justify-between items-center">
            <Link href="/listings">
              <Button variant="ghost" size="sm" className="gap-2 text-muted-foreground hover:text-foreground">
                <ArrowLeft className="w-4 h-4" /> Back to Search
              </Button>
            </Link>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" className="gap-2">
                <Share2 className="w-4 h-4" /> Share
              </Button>
              <Button variant="outline" size="sm" className="gap-2">
                <Heart className="w-4 h-4" /> Save
              </Button>
            </div>
          </div>
        </div>

        {/* Hero Gallery */}
        <div className="h-[400px] md:h-[500px] bg-slate-100 relative group cursor-pointer overflow-hidden">
           <img 
            src={property.image} 
            alt={property.title} 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors flex items-center justify-center">
            <Button variant="secondary" className="opacity-0 group-hover:opacity-100 transition-opacity transform translate-y-4 group-hover:translate-y-0">
              View All Photos
            </Button>
          </div>
        </div>

        <div className="container mx-auto px-4 py-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            
            {/* Main Info */}
            <div className="lg:col-span-2 space-y-8">
              <div>
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <Badge variant="outline" className="mb-3 text-primary border-primary">{property.type}</Badge>
                    <h1 className="font-heading text-3xl md:text-4xl font-bold text-foreground mb-2">
                      {property.title}
                    </h1>
                    <div className="flex items-center gap-2 text-muted-foreground text-lg">
                      <MapPin className="w-5 h-5" />
                      {property.location}
                    </div>
                  </div>
                  <div className="text-right hidden sm:block">
                    <p className="text-3xl font-bold text-primary mb-1">${property.price.toLocaleString()}</p>
                    <p className="text-sm text-muted-foreground">Cash Price</p>
                  </div>
                </div>
                
                {/* Mobile Price */}
                <div className="sm:hidden mb-6">
                  <p className="text-3xl font-bold text-primary mb-1">${property.price.toLocaleString()}</p>
                  <p className="text-sm text-muted-foreground">Cash Price</p>
                </div>

                {/* Key Stats */}
                <div className="grid grid-cols-3 gap-4 border rounded-xl p-6 bg-card text-center">
                  <div>
                    <p className="text-muted-foreground text-sm uppercase tracking-wide mb-1">Acreage</p>
                    <p className="font-bold text-xl">{property.size} ac</p>
                  </div>
                  <div className="border-l">
                    <p className="text-muted-foreground text-sm uppercase tracking-wide mb-1">Price/Acre</p>
                    <p className="font-bold text-xl">${Math.round(property.price / property.size).toLocaleString()}</p>
                  </div>
                  <div className="border-l">
                    <p className="text-muted-foreground text-sm uppercase tracking-wide mb-1">Zoning</p>
                    <p className="font-bold text-xl">Res/Ag</p>
                  </div>
                </div>
              </div>

              {/* Description */}
              <div>
                <h3 className="font-heading text-xl font-bold mb-4">About This Property</h3>
                <p className="text-muted-foreground leading-relaxed whitespace-pre-line text-lg">
                  {property.description}
                  {"\n\n"}
                  This property represents a unique opportunity to own a piece of {property.location}. 
                  Perfect for investment or building your dream project. The area is known for its natural beauty and peaceful surroundings.
                </p>
              </div>

              {/* Features Grid */}
              <div>
                <h3 className="font-heading text-xl font-bold mb-4">Property Features</h3>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  {property.features.map(feature => (
                    <div key={feature} className="flex items-center gap-2 text-foreground">
                      <div className="w-2 h-2 rounded-full bg-primary" />
                      {feature}
                    </div>
                  ))}
                  <div className="flex items-center gap-2 text-foreground"><div className="w-2 h-2 rounded-full bg-primary" />Road Access</div>
                  <div className="flex items-center gap-2 text-foreground"><div className="w-2 h-2 rounded-full bg-primary" />No HOA</div>
                  <div className="flex items-center gap-2 text-foreground"><div className="w-2 h-2 rounded-full bg-primary" />Survey Available</div>
                </div>
              </div>

              {/* Map Stub */}
              <div>
                <h3 className="font-heading text-xl font-bold mb-4">Location</h3>
                <div className="h-[300px] bg-muted rounded-xl flex items-center justify-center text-muted-foreground">
                  <div className="text-center">
                    <MapPin className="w-10 h-10 mx-auto mb-2 opacity-50" />
                    <p>Interactive Map Component Would Go Here</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              <Card className="shadow-lg border-t-4 border-t-primary">
                <CardContent className="p-6">
                  <h3 className="font-heading font-bold text-xl mb-4">Interested in this land?</h3>
                  <p className="text-muted-foreground text-sm mb-6">
                    Contact the seller directly. No middleman fees.
                  </p>
                  
                  <div className="flex items-center gap-3 mb-6">
                    <div className="w-12 h-12 bg-secondary rounded-full flex items-center justify-center text-secondary-foreground font-bold text-lg">
                      JD
                    </div>
                    <div>
                      <p className="font-bold text-foreground">John Doe</p>
                      <p className="text-xs text-muted-foreground flex items-center gap-1">
                        <ShieldCheck className="w-3 h-3 text-primary" /> Verified Seller
                      </p>
                    </div>
                  </div>

                  <form className="space-y-4">
                    <Input placeholder="Your Name" />
                    <Input placeholder="Email Address" type="email" />
                    <Input placeholder="Phone Number" type="tel" />
                    <textarea 
                      className="w-full min-h-[100px] rounded-md border border-input bg-transparent px-3 py-2 text-sm shadow-sm placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50"
                      placeholder="I am interested in this property..."
                      defaultValue={`Hi, I'm interested in the ${property.title} listed for $${property.price.toLocaleString()}.`}
                    />
                    <Button className="w-full text-lg h-12">Send Inquiry</Button>
                  </form>
                  
                  <div className="mt-4 flex flex-col gap-2">
                    <Button variant="outline" className="w-full gap-2">
                      <Phone className="w-4 h-4" /> Show Phone Number
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <h3 className="font-heading font-bold text-md mb-2">Safe Trading Guarantee</h3>
                  <ul className="text-sm text-muted-foreground space-y-2">
                    <li className="flex gap-2"><CheckCircle className="w-4 h-4 text-primary shrink-0" /> Verified Ownership</li>
                    <li className="flex gap-2"><CheckCircle className="w-4 h-4 text-primary shrink-0" /> Secure Escrow Available</li>
                    <li className="flex gap-2"><CheckCircle className="w-4 h-4 text-primary shrink-0" /> Support Team Assistance</li>
                  </ul>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
