import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import PropertyCard from "@/components/property/PropertyCard";
import { properties } from "@/lib/mockData";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Slider } from "@/components/ui/slider";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Search, SlidersHorizontal } from "lucide-react";
import { useState } from "react";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";

export default function Listings() {
  const [priceRange, setPriceRange] = useState([0, 500000]);

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Navbar />
      
      <main className="flex-1 container mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row gap-8">
          
          {/* Filters - Desktop */}
          <aside className="hidden md:block w-64 shrink-0 space-y-8 sticky top-24 self-start">
            <div className="space-y-6">
              <h3 className="font-heading font-bold text-lg">Filters</h3>
              
              <div className="space-y-4">
                <Label>Price Range</Label>
                <Slider 
                  defaultValue={[0, 500000]} 
                  max={1000000} 
                  step={10000}
                  onValueChange={setPriceRange}
                />
                <div className="flex justify-between text-sm text-muted-foreground">
                  <span>${priceRange[0].toLocaleString()}</span>
                  <span>${priceRange[1].toLocaleString()}+</span>
                </div>
              </div>

              <div className="space-y-4">
                <Label>Property Type</Label>
                <div className="space-y-2">
                  {["Raw Land", "Farm", "Ranch", "Waterfront", "Recreational"].map((type) => (
                    <div key={type} className="flex items-center space-x-2">
                      <Checkbox id={type} />
                      <Label htmlFor={type} className="font-normal cursor-pointer">{type}</Label>
                    </div>
                  ))}
                </div>
              </div>

              <div className="space-y-4">
                <Label>Acreage</Label>
                <div className="space-y-2">
                  {["0-1 Acres", "1-5 Acres", "5-20 Acres", "20-100 Acres", "100+ Acres"].map((size) => (
                    <div key={size} className="flex items-center space-x-2">
                      <Checkbox id={size} />
                      <Label htmlFor={size} className="font-normal cursor-pointer">{size}</Label>
                    </div>
                  ))}
                </div>
              </div>

              <Button className="w-full">Apply Filters</Button>
            </div>
          </aside>

          {/* Main Content */}
          <div className="flex-1">
            <div className="flex flex-col sm:flex-row gap-4 justify-between items-center mb-6">
              <h1 className="font-heading text-2xl font-bold">{properties.length} Properties Found</h1>
              
              <div className="flex gap-2 w-full sm:w-auto">
                <div className="relative flex-1 sm:w-64">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input placeholder="Search location..." className="pl-9" />
                </div>
                
                {/* Mobile Filter Trigger */}
                <div className="md:hidden">
                  <Sheet>
                    <SheetTrigger asChild>
                      <Button variant="outline" size="icon">
                        <SlidersHorizontal className="w-4 h-4" />
                      </Button>
                    </SheetTrigger>
                    <SheetContent side="left">
                      {/* Duplicate filter content here for mobile */}
                      <div className="space-y-6 mt-8">
                        <h3 className="font-heading font-bold text-lg">Filters</h3>
                        {/* Simplified for brevity - in real app extract Filter component */}
                        <div className="space-y-4">
                          <Label>Price Range</Label>
                          <Slider defaultValue={[0, 500000]} max={1000000} step={10000} />
                        </div>
                        <Button className="w-full">Apply Filters</Button>
                      </div>
                    </SheetContent>
                  </Sheet>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {properties.map((property) => (
                <PropertyCard key={property.id} property={property} />
              ))}
            </div>
            
            {/* Pagination Stub */}
            <div className="mt-10 flex justify-center gap-2">
              <Button variant="outline" disabled>Previous</Button>
              <Button variant="outline" className="bg-primary text-primary-foreground hover:bg-primary/90 hover:text-primary-foreground border-primary">1</Button>
              <Button variant="outline">2</Button>
              <Button variant="outline">3</Button>
              <Button variant="outline">Next</Button>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
