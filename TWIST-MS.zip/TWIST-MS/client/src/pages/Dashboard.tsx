import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Plus, Settings, Heart, MessageSquare, BarChart3, Edit, Trash2 } from "lucide-react";
import { properties } from "@/lib/mockData";
import { Link } from "wouter";
import { Input } from "@/components/ui/input";

export default function Dashboard() {
  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Navbar />
      
      <main className="flex-1 container mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="font-heading text-3xl font-bold">Dashboard</h1>
            <p className="text-muted-foreground">Welcome back, John Doe</p>
          </div>
          <Button className="gap-2">
            <Plus className="w-4 h-4" /> New Listing
          </Button>
        </div>

        <Tabs defaultValue="listings" className="w-full">
          <TabsList className="mb-8">
            <TabsTrigger value="listings">My Listings</TabsTrigger>
            <TabsTrigger value="favorites">Saved Properties</TabsTrigger>
            <TabsTrigger value="messages">Messages</TabsTrigger>
            <TabsTrigger value="settings">Settings</TabsTrigger>
          </TabsList>
          
          <TabsContent value="listings" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              <StatsCard title="Total Views" value="1,234" icon={BarChart3} trend="+12%" />
              <StatsCard title="Inquiries" value="45" icon={MessageSquare} trend="+5%" />
              <StatsCard title="Active Listings" value="3" icon={Settings} />
            </div>

            <h2 className="font-heading text-xl font-bold mb-4">Active Listings</h2>
            <div className="grid gap-4">
              {properties.slice(0, 3).map((property) => (
                <Card key={property.id} className="flex flex-col md:flex-row overflow-hidden">
                  <div className="w-full md:w-48 h-48 md:h-auto shrink-0 relative">
                     <img 
                      src={property.image} 
                      alt={property.title} 
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <CardContent className="flex-1 p-6 flex flex-col justify-between">
                    <div>
                      <div className="flex justify-between items-start mb-2">
                        <h3 className="font-bold text-lg">{property.title}</h3>
                        <span className="font-bold text-primary">${property.price.toLocaleString()}</span>
                      </div>
                      <p className="text-muted-foreground text-sm line-clamp-2 mb-4">{property.description}</p>
                    </div>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm" className="gap-2"><Edit className="w-4 h-4" /> Edit</Button>
                      <Button variant="outline" size="sm" className="gap-2 text-destructive hover:text-destructive"><Trash2 className="w-4 h-4" /> Delete</Button>
                      <Button variant="ghost" size="sm" className="ml-auto">View Stats</Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
          
          <TabsContent value="favorites">
            <div className="text-center py-12 text-muted-foreground">
              <Heart className="w-12 h-12 mx-auto mb-4 opacity-20" />
              <h3 className="text-lg font-medium">No saved properties yet</h3>
              <p className="mb-4">Start browsing to find your dream land.</p>
              <Link href="/listings"><Button>Browse Listings</Button></Link>
            </div>
          </TabsContent>

           <TabsContent value="messages">
            <Card>
              <CardContent className="p-0">
                <div className="divide-y">
                  {[1, 2, 3].map((i) => (
                    <div key={i} className="p-4 hover:bg-secondary/20 cursor-pointer transition-colors flex gap-4 items-start">
                      <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold">
                        JD
                      </div>
                      <div className="flex-1">
                        <div className="flex justify-between mb-1">
                          <h4 className="font-bold text-sm">Jane Smith</h4>
                          <span className="text-xs text-muted-foreground">2 hours ago</span>
                        </div>
                        <p className="text-sm text-muted-foreground line-clamp-1">
                          Hi, is the 5 Acre Wooded Retreat still available? I'd like to schedule a viewing...
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="settings">
             <Card>
              <CardHeader>
                <CardTitle>Account Settings</CardTitle>
                <CardDescription>Manage your profile and preferences.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">First Name</label>
                    <Input defaultValue="John" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Last Name</label>
                    <Input defaultValue="Doe" />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Email</label>
                  <Input defaultValue="john@example.com" />
                </div>
                <Button>Save Changes</Button>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>

      <Footer />
    </div>
  );
}

function StatsCard({ title, value, icon: Icon, trend }: { title: string, value: string, icon: any, trend?: string }) {
  return (
    <Card>
      <CardContent className="p-6 flex items-center justify-between">
        <div>
          <p className="text-sm font-medium text-muted-foreground mb-1">{title}</p>
          <h3 className="text-2xl font-bold">{value}</h3>
          {trend && <span className="text-xs text-green-600 font-medium">{trend} from last month</span>}
        </div>
        <div className="p-3 bg-primary/10 rounded-full text-primary">
          <Icon className="w-5 h-5" />
        </div>
      </CardContent>
    </Card>
  )
}
