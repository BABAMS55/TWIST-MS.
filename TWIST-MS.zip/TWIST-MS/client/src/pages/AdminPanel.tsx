import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Plus, Edit, Trash2, DollarSign, Users, Home, TrendingUp, Search } from "lucide-react";
import { properties } from "@/lib/mockData";
import { useState } from "react";

export default function AdminPanel() {
  const [activeTab, setActiveTab] = useState("dashboard");
  const [allProperties, setAllProperties] = useState(properties);
  const [searchProperty, setSearchProperty] = useState("");

  // Mock data for statistics
  const stats = {
    totalVisitors: 12843,
    registeredBuyers: 245,
    registeredSellers: 87,
    registeredAgents: 34,
    totalListings: allProperties.length,
    totalRevenue: (allProperties.length * 50) + (87 * 50) + (34 * 50),
  };

  // Mock payment transactions
  const transactions = [
    { id: 1, type: "Listing Fee", amount: 50, seller: "John Doe", date: "2025-01-05", status: "Received" },
    { id: 2, type: "Agent Registration", amount: 50, name: "Sarah Smith", date: "2025-01-04", status: "Received" },
    { id: 3, type: "Listing Fee", amount: 50, seller: "Mike Johnson", date: "2025-01-03", status: "Received" },
    { id: 4, type: "Listing Fee", amount: 50, seller: "Emma Davis", date: "2025-01-02", status: "Received" },
    { id: 5, type: "Agent Registration", amount: 50, name: "Robert Wilson", date: "2025-01-01", status: "Received" },
    { id: 6, type: "Listing Fee", amount: 50, seller: "Lisa Anderson", date: "2024-12-31", status: "Received" },
  ];

  // Mock registered users
  const registeredUsers = [
    { id: 1, name: "John Doe", type: "Seller", email: "john@example.com", joined: "2025-01-05", status: "Active" },
    { id: 2, name: "Sarah Smith", type: "Agent", email: "sarah@example.com", joined: "2025-01-04", status: "Active" },
    { id: 3, name: "Mike Johnson", type: "Seller", email: "mike@example.com", joined: "2025-01-03", status: "Active" },
    { id: 4, name: "Emma Davis", type: "Buyer", email: "emma@example.com", joined: "2025-01-02", status: "Active" },
    { id: 5, name: "Robert Wilson", type: "Agent", email: "robert@example.com", joined: "2025-01-01", status: "Active" },
  ];

  const handleDeleteProperty = (id: string) => {
    setAllProperties(allProperties.filter(p => p.id !== id));
  };

  const filteredProperties = allProperties.filter(p => 
    p.title.toLowerCase().includes(searchProperty.toLowerCase()) ||
    p.location.toLowerCase().includes(searchProperty.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Navbar />
      
      <main className="flex-1">
        <div className="bg-gradient-to-r from-blue-600/20 to-emerald-600/20 py-8 border-b">
          <div className="container mx-auto px-4">
            <h1 className="font-heading text-4xl font-bold text-foreground">Admin Dashboard</h1>
            <p className="text-muted-foreground mt-2">Manage all properties, users, payments and website settings</p>
          </div>
        </div>

        <div className="container mx-auto px-4 py-8">
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-5 mb-8">
              <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
              <TabsTrigger value="properties">Properties</TabsTrigger>
              <TabsTrigger value="payments">Payments</TabsTrigger>
              <TabsTrigger value="users">Users</TabsTrigger>
              <TabsTrigger value="settings">Settings</TabsTrigger>
            </TabsList>

            {/* Dashboard Tab */}
            <TabsContent value="dashboard" className="space-y-6">
              <h2 className="font-heading text-2xl font-bold">Overview</h2>
              
              {/* Stats Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <Card className="bg-gradient-to-br from-blue-50 to-blue-100/50 border-blue-200">
                  <CardContent className="pt-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-muted-foreground font-medium">Total Visitors</p>
                        <p className="text-3xl font-bold text-blue-600 mt-2">{stats.totalVisitors.toLocaleString()}</p>
                        <p className="text-xs text-muted-foreground mt-2">+2.4% from last month</p>
                      </div>
                      <TrendingUp className="w-12 h-12 text-blue-600 opacity-20" />
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-gradient-to-br from-emerald-50 to-emerald-100/50 border-emerald-200">
                  <CardContent className="pt-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-muted-foreground font-medium">Active Listings</p>
                        <p className="text-3xl font-bold text-emerald-600 mt-2">{stats.totalListings}</p>
                        <p className="text-xs text-muted-foreground mt-2">Updated today</p>
                      </div>
                      <Home className="w-12 h-12 text-emerald-600 opacity-20" />
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-gradient-to-br from-amber-50 to-amber-100/50 border-amber-200">
                  <CardContent className="pt-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-muted-foreground font-medium">Total Revenue</p>
                        <p className="text-3xl font-bold text-amber-600 mt-2">${stats.totalRevenue.toLocaleString()}</p>
                        <p className="text-xs text-muted-foreground mt-2">From all fees</p>
                      </div>
                      <DollarSign className="w-12 h-12 text-amber-600 opacity-20" />
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-gradient-to-br from-purple-50 to-purple-100/50 border-purple-200">
                  <CardContent className="pt-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-muted-foreground font-medium">Registered Buyers</p>
                        <p className="text-3xl font-bold text-purple-600 mt-2">{stats.registeredBuyers}</p>
                        <p className="text-xs text-muted-foreground mt-2">Active buyers</p>
                      </div>
                      <Users className="w-12 h-12 text-purple-600 opacity-20" />
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-gradient-to-br from-red-50 to-red-100/50 border-red-200">
                  <CardContent className="pt-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-muted-foreground font-medium">Registered Sellers</p>
                        <p className="text-3xl font-bold text-red-600 mt-2">{stats.registeredSellers}</p>
                        <p className="text-xs text-muted-foreground mt-2">Active sellers</p>
                      </div>
                      <Users className="w-12 h-12 text-red-600 opacity-20" />
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-gradient-to-br from-cyan-50 to-cyan-100/50 border-cyan-200">
                  <CardContent className="pt-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-muted-foreground font-medium">Registered Agents</p>
                        <p className="text-3xl font-bold text-cyan-600 mt-2">{stats.registeredAgents}</p>
                        <p className="text-xs text-muted-foreground mt-2">Professional agents</p>
                      </div>
                      <Users className="w-12 h-12 text-cyan-600 opacity-20" />
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Recent Activity */}
              <Card>
                <CardHeader>
                  <CardTitle>Recent Transactions</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {transactions.slice(0, 5).map((tx) => (
                      <div key={tx.id} className="flex items-center justify-between pb-4 border-b last:border-0">
                        <div className="flex-1">
                          <p className="font-medium text-sm">{tx.type}</p>
                          <p className="text-xs text-muted-foreground">{tx.seller || tx.name} • {tx.date}</p>
                        </div>
                        <div className="text-right">
                          <p className="font-bold text-emerald-600">+${tx.amount}</p>
                          <p className="text-xs text-muted-foreground">{tx.status}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Properties Tab */}
            <TabsContent value="properties" className="space-y-6">
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
                <h2 className="font-heading text-xl font-bold">All Properties</h2>
                <Button className="gap-2">
                  <Plus className="w-4 h-4" /> Add New Property
                </Button>
              </div>

              {/* Search */}
              <div className="relative mb-6">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
                <Input 
                  placeholder="Search by title or location..." 
                  className="pl-10"
                  value={searchProperty}
                  onChange={(e) => setSearchProperty(e.target.value)}
                />
              </div>

              {/* Properties Table */}
              <div className="overflow-x-auto border rounded-lg bg-white">
                <table className="w-full">
                  <thead className="bg-secondary/30 border-b">
                    <tr>
                      <th className="px-6 py-3 text-left text-sm font-semibold">Title</th>
                      <th className="px-6 py-3 text-left text-sm font-semibold">Price</th>
                      <th className="px-6 py-3 text-left text-sm font-semibold">Location</th>
                      <th className="px-6 py-3 text-left text-sm font-semibold">Acres</th>
                      <th className="px-6 py-3 text-left text-sm font-semibold">Type</th>
                      <th className="px-6 py-3 text-left text-sm font-semibold">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredProperties.map((property) => (
                      <tr key={property.id} className="border-b hover:bg-secondary/10 transition-colors">
                        <td className="px-6 py-4 text-sm font-medium">{property.title}</td>
                        <td className="px-6 py-4 text-sm font-semibold text-emerald-600">${property.price.toLocaleString()}</td>
                        <td className="px-6 py-4 text-sm">{property.location}</td>
                        <td className="px-6 py-4 text-sm">{property.size} ac</td>
                        <td className="px-6 py-4 text-sm">
                          <span className="inline-block px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-xs font-medium">
                            {property.type}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-sm flex gap-2">
                          <Button variant="outline" size="sm" className="gap-1">
                            <Edit className="w-3 h-3" /> Edit
                          </Button>
                          <Button 
                            variant="outline" 
                            size="sm" 
                            className="gap-1 text-destructive hover:text-destructive"
                            onClick={() => handleDeleteProperty(property.id)}
                          >
                            <Trash2 className="w-3 h-3" /> Delete
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <p className="text-sm text-muted-foreground">Total: {filteredProperties.length} properties</p>
            </TabsContent>

            {/* Payments Tab */}
            <TabsContent value="payments" className="space-y-6">
              <h2 className="font-heading text-xl font-bold">Payment Transactions</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                <Card>
                  <CardContent className="pt-6">
                    <p className="text-sm text-muted-foreground">Total Received</p>
                    <p className="text-2xl font-bold text-emerald-600 mt-2">${transactions.reduce((sum, t) => sum + t.amount, 0)}</p>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="pt-6">
                    <p className="text-sm text-muted-foreground">Total Transactions</p>
                    <p className="text-2xl font-bold text-blue-600 mt-2">{transactions.length}</p>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="pt-6">
                    <p className="text-sm text-muted-foreground">Average Transaction</p>
                    <p className="text-2xl font-bold text-purple-600 mt-2">${(transactions.reduce((sum, t) => sum + t.amount, 0) / transactions.length).toFixed(0)}</p>
                  </CardContent>
                </Card>
              </div>

              {/* Transactions Table */}
              <div className="overflow-x-auto border rounded-lg bg-white">
                <table className="w-full">
                  <thead className="bg-secondary/30 border-b">
                    <tr>
                      <th className="px-6 py-3 text-left text-sm font-semibold">Type</th>
                      <th className="px-6 py-3 text-left text-sm font-semibold">From/Name</th>
                      <th className="px-6 py-3 text-left text-sm font-semibold">Amount</th>
                      <th className="px-6 py-3 text-left text-sm font-semibold">Date</th>
                      <th className="px-6 py-3 text-left text-sm font-semibold">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {transactions.map((tx) => (
                      <tr key={tx.id} className="border-b hover:bg-secondary/10 transition-colors">
                        <td className="px-6 py-4 text-sm font-medium">{tx.type}</td>
                        <td className="px-6 py-4 text-sm">{tx.seller || tx.name}</td>
                        <td className="px-6 py-4 text-sm">
                          <span className="font-bold text-emerald-600">${tx.amount}</span>
                        </td>
                        <td className="px-6 py-4 text-sm text-muted-foreground">{tx.date}</td>
                        <td className="px-6 py-4 text-sm">
                          <span className="inline-block px-3 py-1 bg-green-100 text-green-700 rounded-full text-xs font-medium">
                            {tx.status}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </TabsContent>

            {/* Users Tab */}
            <TabsContent value="users" className="space-y-6">
              <div className="flex justify-between items-center mb-6">
                <h2 className="font-heading text-xl font-bold">Registered Users</h2>
              </div>

              <div className="overflow-x-auto border rounded-lg bg-white">
                <table className="w-full">
                  <thead className="bg-secondary/30 border-b">
                    <tr>
                      <th className="px-6 py-3 text-left text-sm font-semibold">Name</th>
                      <th className="px-6 py-3 text-left text-sm font-semibold">Type</th>
                      <th className="px-6 py-3 text-left text-sm font-semibold">Email</th>
                      <th className="px-6 py-3 text-left text-sm font-semibold">Joined</th>
                      <th className="px-6 py-3 text-left text-sm font-semibold">Status</th>
                      <th className="px-6 py-3 text-left text-sm font-semibold">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {registeredUsers.map((user) => (
                      <tr key={user.id} className="border-b hover:bg-secondary/10 transition-colors">
                        <td className="px-6 py-4 text-sm font-medium">{user.name}</td>
                        <td className="px-6 py-4 text-sm">
                          <span className={`inline-block px-3 py-1 rounded-full text-xs font-medium ${
                            user.type === 'Buyer' ? 'bg-purple-100 text-purple-700' :
                            user.type === 'Seller' ? 'bg-red-100 text-red-700' :
                            'bg-cyan-100 text-cyan-700'
                          }`}>
                            {user.type}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-sm">{user.email}</td>
                        <td className="px-6 py-4 text-sm text-muted-foreground">{user.joined}</td>
                        <td className="px-6 py-4 text-sm">
                          <span className="inline-block px-3 py-1 bg-green-100 text-green-700 rounded-full text-xs font-medium">
                            {user.status}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-sm flex gap-2">
                          <Button variant="outline" size="sm">View</Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </TabsContent>

            {/* Settings Tab */}
            <TabsContent value="settings" className="space-y-6">
              <h2 className="font-heading text-xl font-bold">Website Settings</h2>
              
              <Card>
                <CardHeader>
                  <CardTitle>General Settings</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <Label>Site Name</Label>
                      <Input defaultValue="TWIST MS Real Estate" />
                    </div>
                    <div className="space-y-2">
                      <Label>Support Email</Label>
                      <Input defaultValue="twistms.usa@gmail.com" type="email" />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label>Site Description</Label>
                    <textarea className="flex min-h-[100px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm shadow-sm placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50" defaultValue="The most trusted marketplace for buying and selling land. Connect directly with owners and find exclusive off-market deals." />
                  </div>
                  <Button>Save Settings</Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Fee Configuration</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label>Property Listing Fee ($)</Label>
                    <Input type="number" defaultValue="50" />
                  </div>
                  <div className="space-y-2">
                    <Label>Agent Registration Fee ($)</Label>
                    <Input type="number" defaultValue="50" />
                  </div>
                  <Button>Update Fees</Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Social Media Links</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label>Instagram</Label>
                    <Input defaultValue="@twistms_realestate" />
                  </div>
                  <div className="space-y-2">
                    <Label>TikTok</Label>
                    <Input defaultValue="Twistms real estate" />
                  </div>
                  <Button>Update Social Links</Button>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>

      <Footer />
    </div>
  );
}
