import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { MapPin, Ruler, ArrowRight, Heart } from "lucide-react";
import { Property } from "@/lib/mockData";
import { Link } from "wouter";

interface PropertyCardProps {
  property: Property;
}

export default function PropertyCard({ property }: PropertyCardProps) {
  return (
    <Card className="group overflow-hidden border-none shadow-md hover:shadow-xl transition-all duration-300 flex flex-col h-full bg-card">
      {/* Image Container */}
      <div className="relative h-64 overflow-hidden">
        <img 
          src={property.image} 
          alt={property.title} 
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
        />
        <div className="absolute top-4 left-4">
          <Badge className="bg-background/90 text-foreground backdrop-blur-sm shadow-sm hover:bg-background/100 border-none font-medium">
            {property.type}
          </Badge>
        </div>
        <button className="absolute top-4 right-4 p-2 rounded-full bg-background/50 text-white hover:bg-background hover:text-red-500 transition-colors backdrop-blur-sm opacity-0 group-hover:opacity-100">
          <Heart className="w-5 h-5" />
        </button>
        <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/60 to-transparent p-4">
          <p className="text-white font-bold text-2xl tracking-tight">
            ${property.price.toLocaleString()}
          </p>
        </div>
      </div>

      {/* Content */}
      <CardContent className="p-5 flex-1">
        <div className="flex items-start justify-between mb-3">
          <h3 className="font-heading font-semibold text-xl line-clamp-1 group-hover:text-primary transition-colors">
            {property.title}
          </h3>
        </div>
        
        <div className="flex items-center gap-4 text-muted-foreground text-sm mb-4">
          <div className="flex items-center gap-1">
            <MapPin className="w-4 h-4 text-primary" />
            {property.location}
          </div>
          <div className="flex items-center gap-1">
            <Ruler className="w-4 h-4 text-primary" />
            {property.size} Acres
          </div>
        </div>

        <p className="text-muted-foreground text-sm line-clamp-2 leading-relaxed">
          {property.description}
        </p>
      </CardContent>

      {/* Footer */}
      <CardFooter className="p-5 pt-0 mt-auto">
        <Link href={`/property/${property.id}`} className="w-full">
          <Button variant="outline" className="w-full group-hover:border-primary group-hover:text-primary transition-colors">
            View Details <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
          </Button>
        </Link>
      </CardFooter>
    </Card>
  );
}
