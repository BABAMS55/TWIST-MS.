import { Link, useLocation } from "wouter";
import { Menu } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import logoImage from '@assets/Brown_and_White_Simple_Real_Estate_Logo_20250812_104815_0000_1767103670960.png';

export default function Navbar() {
  const [location] = useLocation();
  const [isOpen, setIsOpen] = useState(false);

  const navLinks = [
    { href: "/listings", label: "Buy Land" },
    { href: "/sell", label: "Sell Land" },
    { href: "/invest", label: "Invest" },
    { href: "/agents", label: "Agents" },
  ];

  return (
    <nav className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-0 z-50">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-600 to-blue-500 flex items-center justify-center shadow-md overflow-hidden flex-shrink-0">
            <img 
              src={logoImage} 
              alt="TWIST MS" 
              className="w-10 h-10 object-cover object-center"
            />
          </div>
          <span className="font-heading font-bold text-lg tracking-tight text-foreground">
            TWIST MS
          </span>
        </Link>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <Link key={link.href} href={link.href}>
              <span className={`text-sm font-medium transition-colors hover:text-primary cursor-pointer ${
                location === link.href ? "text-primary" : "text-muted-foreground"
              }`}>
                {link.label}
              </span>
            </Link>
          ))}
        </div>

        {/* Desktop Auth */}
        <div className="hidden md:flex items-center gap-4">
          <Link href="/auth?tab=login">
            <Button variant="ghost" size="sm" className="font-medium cursor-pointer">
              Sign In
            </Button>
          </Link>
          <Link href="/sell">
            <Button size="sm" className="font-medium cursor-pointer">
              List Your Land
            </Button>
          </Link>
        </div>

        {/* Mobile Menu */}
        <div className="md:hidden">
          <Sheet open={isOpen} onOpenChange={setIsOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon">
                <Menu className="h-6 w-6" />
              </Button>
            </SheetTrigger>
            <SheetContent>
              <div className="flex flex-col gap-6 mt-8">
                {navLinks.map((link) => (
                  <Link key={link.href} href={link.href} onClick={() => setIsOpen(false)}>
                    <span className={`text-lg font-medium ${
                      location === link.href ? "text-primary" : "text-foreground"
                    }`}>
                      {link.label}
                    </span>
                  </Link>
                ))}
                <div className="h-px bg-border my-2" />
                <Link href="/auth?tab=login" onClick={() => setIsOpen(false)}>
                  <span className="flex items-center gap-2 text-lg font-medium">
                    Sign In
                  </span>
                </Link>
                <Link href="/sell" onClick={() => setIsOpen(false)}>
                  <Button className="w-full">List Your Land</Button>
                </Link>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </nav>
  );
}
