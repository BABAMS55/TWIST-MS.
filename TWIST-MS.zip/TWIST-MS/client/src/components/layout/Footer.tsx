import { Link } from "wouter";
import { Instagram, Mail, Phone } from "lucide-react";
import logoImage from '@assets/Brown_and_White_Simple_Real_Estate_Logo_20250812_104815_0000_1767103670960.png';

export default function Footer() {
  return (
    <footer className="bg-secondary/30 pt-16 pb-8 border-t">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
          {/* Brand */}
          <div className="space-y-4 md:col-span-2">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 rounded-full bg-gradient-to-br from-blue-600 to-blue-500 flex items-center justify-center shadow-lg overflow-hidden flex-shrink-0">
                <img 
                  src={logoImage} 
                  alt="TWIST MS" 
                  className="w-16 h-16 object-cover object-center"
                />
              </div>
              <div>
                <h3 className="font-heading font-bold text-2xl text-foreground">
                  TWIST MS
                </h3>
              </div>
            </div>
            <p className="text-muted-foreground text-sm leading-relaxed font-medium">
              The most trusted marketplace for buying and selling land. Connect directly with owners and find exclusive off-market deals
            </p>
          </div>

          {/* Contact */}
          <div>
            <h3 className="font-heading font-bold mb-4">Contact & Follow</h3>
            <ul className="space-y-3 text-sm text-muted-foreground">
              <li className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-primary shrink-0" />
                <span>twistms.usa@gmail.com</span>
              </li>
              <li className="flex items-center gap-2">
                <Instagram className="w-4 h-4 text-primary shrink-0" />
                <span>@twistms_realestate</span>
              </li>
              <li className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-primary shrink-0" />
                <span>TikTok: Twistms real estate</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t pt-8 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-sm text-muted-foreground">
            © {new Date().getFullYear()} TWIST MS Real Estate. All rights reserved
          </p>
          <div className="flex items-center gap-4">
            <a href="https://instagram.com/twistms_realestate" target="_blank" rel="noopener noreferrer" className="w-8 h-8 flex items-center justify-center rounded-full bg-background border hover:bg-primary hover:text-white transition-colors text-muted-foreground">
              <Instagram className="w-4 h-4" />
            </a>
            <a href="#" className="w-8 h-8 flex items-center justify-center rounded-full bg-background border hover:bg-primary hover:text-white transition-colors text-muted-foreground">
              <Phone className="w-4 h-4" />
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
