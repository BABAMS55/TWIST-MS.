import { Search, MapPin } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import heroImage from '@assets/generated_images/aerial_view_of_beautiful_green_land_plots_for_real_estate_website_hero..png';

export default function Hero() {
  return (
    <div className="relative min-h-[600px] flex items-center justify-center overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-r from-black/60 to-black/30 z-10" />
        <img 
          src={heroImage} 
          alt="Aerial view of land" 
          className="w-full h-full object-cover"
        />
      </div>

      {/* Content */}
      <div className="relative z-20 container mx-auto px-4 text-center">
        <h1 className="font-heading text-4xl md:text-6xl font-bold text-white mb-6 leading-tight animate-in fade-in slide-in-from-bottom-4 duration-700">
          Find Your Perfect<br />Piece of Earth
        </h1>
        <p className="text-lg md:text-xl text-white/90 max-w-2xl mx-auto mb-10 animate-in fade-in slide-in-from-bottom-4 duration-700 delay-100">
          The most trusted marketplace for buying and selling land. 
          Connect directly with owners and find exclusive off-market deals.
        </p>

        {/* Search Bar */}
        <div className="bg-white p-4 rounded-xl shadow-2xl max-w-4xl mx-auto flex flex-col md:flex-row gap-4 animate-in fade-in slide-in-from-bottom-8 duration-700 delay-200">
          <div className="flex-1 relative">
            <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <Input 
              placeholder="City, County, or Zip Code" 
              className="pl-10 h-12 border-0 bg-secondary/30 focus-visible:ring-0 focus-visible:bg-secondary/50 transition-colors"
            />
          </div>
          <div className="w-full md:w-48">
            <Select>
              <SelectTrigger className="h-12 border-0 bg-secondary/30 focus:ring-0">
                <SelectValue placeholder="Property Type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="raw">Raw Land</SelectItem>
                <SelectItem value="farm">Farm & Ranch</SelectItem>
                <SelectItem value="water">Waterfront</SelectItem>
                <SelectItem value="rec">Recreational</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="w-full md:w-48">
            <Select>
              <SelectTrigger className="h-12 border-0 bg-secondary/30 focus:ring-0">
                <SelectValue placeholder="Max Price" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="10k">$10,000</SelectItem>
                <SelectItem value="50k">$50,000</SelectItem>
                <SelectItem value="100k">$100,000</SelectItem>
                <SelectItem value="500k">$500,000</SelectItem>
                <SelectItem value="1m">$1,000,000+</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <Button size="lg" className="h-12 px-8 text-base font-semibold shadow-md hover:shadow-lg transition-all">
            Search
          </Button>
        </div>
      </div>
    </div>
  );
}
